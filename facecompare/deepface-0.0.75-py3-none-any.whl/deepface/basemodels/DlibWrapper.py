from deepface.basemodels.DlibResNet import DlibResNet

def loadModel():
	return DlibResNet()